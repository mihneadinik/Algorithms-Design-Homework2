import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.PriorityQueue;
import java.util.Scanner;

class Pair implements Comparable {
    public int x;
    public int y;
    public char direction;
    public int cost;

    Pair(int x, int y, char direction, int cost) {
        this.x = x;
        this.y = y;
        this.direction = direction;
        this.cost = cost;
    }

    @Override
    public int compareTo(Object arg0) {
        if (this.cost < ((Pair)arg0).cost) {
            return -1;
        }
        return 1;
    }
}

public class Beamdrone {
	public Integer N;
    public Integer M;
    public Integer Xi;
    public Integer Yi;
    public Integer Xf;
    public Integer Yf;
    public char[][] matrix;
    public int[][] visited_and_costs;

	// Function that reads the input file
	public void read() throws FileNotFoundException {
		File input = new File("beamdrone.in");
		Scanner scanner = new Scanner(input);
		this.N = scanner.nextInt();
        this.M = scanner.nextInt();
        this.Xi = scanner.nextInt();
        this.Yi = scanner.nextInt();
        this.Xf = scanner.nextInt();
        this.Yf = scanner.nextInt();

        this.matrix = new char[this.N][this.M];

		for (int i = 0; i < this.N; i++) {
            String line = scanner.next();
			for (int j = 0; j < this.M; j++) {
                this.matrix[i][j] = line.charAt(j);
            }
		}

		scanner.close();
	}

    public void initialise_visited() {
        this.visited_and_costs = new int [this.N][this.M];
        for (int i = 0; i < this.N; i++) {
			for (int j = 0; j < this.M; j++) {
                this.visited_and_costs[i][j] = -1;
            }
		}
    }

    public boolean check_borders(int x, int y) {
        if (x < 0 || x >= this.M) {
            return false;
        }
    
        if (y < 0 || y >= this.N) {
            return false;
        }
    
        return true;
    }

	public boolean check_wall(int x, int y) {
        if (this.matrix[x][y] == 'W') {
            return true;
        }
    
        return false;
    }

    public boolean check_final_destination(int x, int y) {
        if (x == this.Xf && y == this.Yf) {
            return true;
        }
    
        return false;
    }

    public int solve() {
        // initialise a priority_queue that will keep pairs of locations and directions with costs sorted in increasing order by cost
        // {{{posX, posY}, Dir}, Cost}
        PriorityQueue<Pair> q = new PriorityQueue<>();
        // add starting position
        Pair start = new Pair(this.Xi, this.Yi, 'a', 0);
        q.add(start);
        visited_and_costs[Xi][Yi] = 0;
        while (!q.isEmpty()) {
            // extract the smallest cost in the queue
            Pair curr = q.poll();
            int curr_x = curr.x;
            int curr_y = curr.y;
            char prev_dir = curr.direction;
            int curr_cost = curr.cost;
    
            System.out.println(curr_x + " " + curr_y + " " + curr_cost);
            // visited before but with a bigger cost => skip
            if (curr_x != Xi && curr_y != Yi && visited_and_costs[curr_x][curr_y] != -1 && visited_and_costs[curr_x][curr_y] < curr_cost) {
                continue;
            }
    
            // mark location as visited
            visited_and_costs[curr_x][curr_y] = curr_cost;
    
            // check if it is the final destination
            if (check_final_destination(curr_x, curr_y)) {
                return curr_cost;
            }
    
            // add its neighbours to the queue with updated cost if necessary
            // going NORTH
            if (check_borders(curr_x - 1, curr_y) && !check_wall(curr_x - 1, curr_y)) {
                if (prev_dir == 'a' || prev_dir == 'n') {
                    // same cost, no need to take a turn
                    if (visited_and_costs[curr_x - 1][curr_y] == -1 || visited_and_costs[curr_x - 1][curr_y] >= curr_cost) {
                        Pair to_add = new Pair(curr_x - 1, curr_y, 'n', curr_cost);
                        q.add(to_add);
                        visited_and_costs[curr_x - 1][curr_y] = curr_cost;
                    }
                } else {
                    // need to take a turn, cost increases
                    if (visited_and_costs[curr_x - 1][curr_y] == -1 || visited_and_costs[curr_x - 1][curr_y] > curr_cost) {
                        Pair to_add = new Pair(curr_x - 1, curr_y, 'n', curr_cost + 1);
                        q.add(to_add);
                        visited_and_costs[curr_x - 1][curr_y] = curr_cost + 1;
                    }
                }
            }
    
            // going SOUTH
            if (check_borders(curr_x + 1, curr_y) && !check_wall(curr_x + 1, curr_y)) {
                if (prev_dir == 'a' || prev_dir == 's') {
                    // same cost, no need to take a turn
                    if (visited_and_costs[curr_x + 1][curr_y] == -1 || visited_and_costs[curr_x + 1][curr_y] >= curr_cost) {
                        Pair to_add = new Pair(curr_x + 1, curr_y, 's', curr_cost);
                        q.add(to_add);
                        visited_and_costs[curr_x + 1][curr_y] = curr_cost;
                    }
                } else {
                    // need to take a turn, cost increases
                    if (visited_and_costs[curr_x + 1][curr_y] == -1 || visited_and_costs[curr_x + 1][curr_y] > curr_cost) {
                        Pair to_add = new Pair(curr_x + 1, curr_y, 's', curr_cost + 1);
                        q.add(to_add);
                        visited_and_costs[curr_x + 1][curr_y] = curr_cost + 1;
                    }
                }
            }
    
            // going WEST
            if (check_borders(curr_x, curr_y - 1) && !check_wall(curr_x, curr_y - 1)) {
                if (prev_dir == 'a' || prev_dir == 'w') {
                    // same cost, no need to take a turn
                    if (visited_and_costs[curr_x][curr_y - 1] == -1 || visited_and_costs[curr_x][curr_y - 1] >= curr_cost) {
                        Pair to_add = new Pair(curr_x, curr_y - 1, 'w', curr_cost);
                        q.add(to_add);
                        visited_and_costs[curr_x][curr_y - 1] = curr_cost;
                    }
                } else {
                    // need to take a turn, cost increases
                    if (visited_and_costs[curr_x][curr_y - 1] == -1 || visited_and_costs[curr_x][curr_y - 1] > curr_cost) {
                        Pair to_add = new Pair(curr_x, curr_y - 1, 'w', curr_cost + 1);
                        q.add(to_add);
                        visited_and_costs[curr_x][curr_y - 1] = curr_cost + 1;
                    }
                }
            }
    
            // going EAST
            if (check_borders(curr_x, curr_y + 1) && !check_wall(curr_x, curr_y + 1)) {
                if (prev_dir == 'a' || prev_dir == 'e') {
                    // same cost, no need to take a turn
                    if (visited_and_costs[curr_x][curr_y + 1] == -1 || visited_and_costs[curr_x][curr_y + 1] >= curr_cost) {
                        Pair to_add = new Pair(curr_x, curr_y + 1, 'e', curr_cost);
                        q.add(to_add);
                        visited_and_costs[curr_x][curr_y + 1] = curr_cost;
                    }
                } else {
                    // need to take a turn, cost increases
                    if (visited_and_costs[curr_x][curr_y + 1] == -1 || visited_and_costs[curr_x][curr_y + 1] > curr_cost) {
                        Pair to_add = new Pair(curr_x, curr_y + 1, 'e', curr_cost + 1);
                        q.add(to_add);
                        visited_and_costs[curr_x][curr_y + 1] = curr_cost + 1;
                    }
                }
            }
        }
    
        return -1;
    }

	public static void main(String[] args) throws IOException {
		Beamdrone pb = new Beamdrone();
		pb.read();
        pb.initialise_visited();

		PrintWriter printWriter = new PrintWriter(new FileWriter("beamdrone.out"));
		printWriter.println(pb.solve());
		printWriter.close();
	}
}