#include <fstream>
#include <vector>
#include <queue>

#define file_in "beamdrone.in"
#define file_out "beamdrone.out"

#define NORTH 'n'
#define SOUTH 's'
#define WEST 'w'
#define EAST 'e'
#define ANY 'a'  // used for starting position

std::vector<std::vector<char>> matrix;
std::vector<std::vector<int>> costs;
int N, M, Xi, Yi, Xf, Yf;

// function that reads the input data
void read() {
    std::ifstream in;
    in.open(file_in);

    in >> N >> M >> Xi >> Yi >> Xf >> Yf;

    for (int i = 0; i < N; i++) {
        std::vector<char> line;
        for (int j = 0; j < M; j++) {
            char r;
            in >> r;
            line.push_back(r);
        }
        matrix.push_back(line);
    }
}

void initialise_visited() {
    for (int i = 0; i < N; i++) {
        std::vector<int> line(M, -1);
        costs.push_back(line);
    }
}

// function that checks if a location is inside the borders
// true -> inside borders
// false -> outside borders
bool check_borders(int x, int y) {
    if (x < 0 || x >= N) {
        return false;
    }

    if (y < 0 || y >= M) {
        return false;
    }

    return true;
}

// function that checks if a location is in a wall position
// true -> it is a wall
// false -> it is not a wall
bool check_wall(int x, int y) {
    if (matrix[x][y] == 'W') {
        return true;
    }

    return false;
}

// function that checks if a location is the destination position
// true -> it is
// false -> it is not
bool check_final_destination(int x, int y) {
    if (x == Xf && y == Yf) {
        return true;
    }

    return false;
}

// function that computes the minimum distance to target
int compute_min() {
    // initialise a priority_queue that will keep pairs of locations
    // and directions with costs sorted in increasing order by cost
    // {{{posX, posY}, Dir}, Cost}
    auto cmp = [](std::pair<std::pair<std::pair<int, int>, char>, int> left,
                    std::pair<std::pair<std::pair<int, int>, char>, int> right)
                    { return left.second > right.second; };

    std::priority_queue<std::pair<std::pair<std::pair<int, int>, char>, int>,
            std::vector<std::pair<std::pair<std::pair<int, int>, char>, int>>,
                decltype(cmp)> q(cmp);

    // add starting position
    q.push({{{Xi, Yi}, ANY}, 0});
    costs[Xi][Yi] = 0;
    while (!q.empty()) {
        char no_go = ANY;
        // extract the smallest cost in the queue
        std::pair<std::pair<std::pair<int, int>, char>, int> curr = q.top();
        q.pop();
        int curr_x = curr.first.first.first;
        int curr_y = curr.first.first.second;
        char prev_dir = curr.first.second;
        int curr_cost = curr.second;

        // visited before but with a bigger cost now => skip
        if (curr_x != Xi && curr_y != Yi && costs[curr_x][curr_y] != -1 &&
            costs[curr_x][curr_y] < curr_cost) {
            continue;
        }

        // mark location as visited
        costs[curr_x][curr_y] = curr_cost;

        // check if it is the final destination
        if (check_final_destination(curr_x, curr_y)) {
            return curr_cost;
        }

        // don't turn 180 degrees
        if (prev_dir == NORTH) {
            no_go = SOUTH;
        }
        if (prev_dir == SOUTH) {
            no_go = NORTH;
        }
        if (prev_dir == EAST) {
            no_go = WEST;
        }
        if (prev_dir == WEST) {
            no_go = EAST;
        }

        // add its neighbours to the queue with updated cost if necessary
        // going NORTH
        if (no_go != NORTH && check_borders(curr_x - 1, curr_y) &&
                                !check_wall(curr_x - 1, curr_y)) {
            if (prev_dir == ANY || prev_dir == NORTH) {
                // same cost, no need to take a turn
                if (costs[curr_x - 1][curr_y] == -1 ||
                    costs[curr_x - 1][curr_y] >= curr_cost) {
                    q.push({{{curr_x - 1, curr_y}, NORTH}, curr_cost});
                }
            } else {
                // need to take a turn, cost increases
                if (costs[curr_x - 1][curr_y] == -1 ||
                    costs[curr_x - 1][curr_y] > curr_cost) {
                    q.push({{{curr_x - 1, curr_y}, NORTH}, curr_cost + 1});
                }
            }
        }

        // going SOUTH
        if (no_go != SOUTH && check_borders(curr_x + 1, curr_y) &&
                                !check_wall(curr_x + 1, curr_y)) {
            if (prev_dir == ANY || prev_dir == SOUTH) {
                // same cost, no need to take a turn
                if (costs[curr_x + 1][curr_y] == -1 ||
                    costs[curr_x + 1][curr_y] >= curr_cost) {
                    q.push({{{curr_x + 1, curr_y}, SOUTH}, curr_cost});
                }
            } else {
                // need to take a turn, cost increases
                if (costs[curr_x + 1][curr_y] == -1 ||
                    costs[curr_x + 1][curr_y] > curr_cost) {
                    q.push({{{curr_x + 1, curr_y}, SOUTH}, curr_cost + 1});
                }
            }
        }

        // going WEST
        if (no_go != WEST && check_borders(curr_x, curr_y - 1) &&
                            !check_wall(curr_x, curr_y - 1)) {
            if (prev_dir == ANY || prev_dir == WEST) {
                // same cost, no need to take a turn
                if (costs[curr_x][curr_y - 1] == -1 ||
                    costs[curr_x][curr_y - 1] >= curr_cost) {
                    q.push({{{curr_x, curr_y - 1}, WEST}, curr_cost});
                }
            } else {
                // need to take a turn, cost increases
                if (costs[curr_x][curr_y - 1] == -1 ||
                    costs[curr_x][curr_y - 1] > curr_cost) {
                    q.push({{{curr_x, curr_y - 1}, WEST}, curr_cost + 1});
                }
            }
        }

        // going EAST
        if (no_go != EAST && check_borders(curr_x, curr_y + 1) &&
                            !check_wall(curr_x, curr_y + 1)) {
            if (prev_dir == ANY || prev_dir == EAST) {
                // same cost, no need to take a turn
                if (costs[curr_x][curr_y + 1] == -1 ||
                    costs[curr_x][curr_y + 1] >= curr_cost) {
                    q.push({{{curr_x, curr_y + 1}, EAST}, curr_cost});
                }
            } else {
                // need to take a turn, cost increases
                if (costs[curr_x][curr_y + 1] == -1 ||
                    costs[curr_x][curr_y + 1] > curr_cost) {
                    q.push({{{curr_x, curr_y + 1}, EAST}, curr_cost + 1});
                }
            }
        }
    }

    return -1;
}

int main() {
    std::ofstream out;
    out.open(file_out);

    read();
    initialise_visited();
    int cost = compute_min();
    out << cost;
    return 0;
}